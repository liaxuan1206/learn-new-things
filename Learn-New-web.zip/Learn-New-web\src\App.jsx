import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  BookOpen,
  Books,
  Brain,
  CalendarBlank,
  CaretDown,
  CaretRight,
  ChartBar,
  Check,
  CheckCircle,
  CircleNotch,
  ClockCounterClockwise,
  Compass,
  FilePdf,
  FileText,
  FolderOpen,
  Gear,
  GraduationCap,
  House,
  Key,
  Lightbulb,
  ListChecks,
  LockKey,
  MagnifyingGlass,
  MapTrifold,
  Microphone,
  PaperPlaneTilt,
  PencilSimple,
  Plus,
  Question,
  SealCheck,
  ShieldCheck,
  SignOut,
  SlidersHorizontal,
  Sparkle,
  Star,
  Target,
  TrendUp,
  UploadSimple,
  User,
  UserCircle,
  X,
} from "@phosphor-icons/react";
import {
  calibrationItems,
  feedbackByMode,
  historyItems,
  knowledgePacks,
} from "./data.js";

const STAGES = [
  { id: "materials", label: "准备资料", copy: "选资料", icon: FolderOpen },
  { id: "map", label: "确认路径", copy: "看顺序", icon: MapTrifold },
  { id: "lesson", label: "简单讲解", copy: "先听懂", icon: BookOpen },
  { id: "check", label: "掌握检查", copy: "再验证", icon: ListChecks },
  { id: "deep", label: "费曼 · 苏格拉底", copy: "讲出来", icon: Brain },
];

const LEARNING_PATH = [
  {
    id: "overview",
    title: "建立全局框架",
    goal: "先理解为什么大脑需要两套思考系统",
    method: "3 分钟引导",
    doneWhen: "能说出两套系统的基本差异",
    duration: "3 分钟",
    status: "completed",
  },
  {
    id: "system1",
    title: "学会识别系统 1",
    goal: "判断哪些反应来自快速直觉",
    method: "简单讲解 + 常驻生活例子",
    doneWhen: "能从日常行为中找出一个系统 1",
    duration: "7 分钟",
    status: "current",
  },
  {
    id: "system2",
    title: "学会调用系统 2",
    goal: "知道什么时候必须停下来分析",
    method: "对比讲解 + 小练习",
    doneWhen: "能判断一个任务是否需要主动分析",
    duration: "8 分钟",
    status: "queued",
  },
  {
    id: "cooperate",
    title: "看见两者如何协作",
    goal: "理解它们不是对错关系，而是不同分工",
    method: "情境判断",
    doneWhen: "能解释一次从直觉切换到分析的过程",
    duration: "6 分钟",
    status: "queued",
  },
  {
    id: "bias",
    title: "识别常见认知偏差",
    goal: "认识锚定、损失厌恶与框架效应",
    method: "案例拆解",
    doneWhen: "能指出案例中是哪一种偏差",
    duration: "10 分钟",
    status: "queued",
  },
  {
    id: "teachback",
    title: "讲给 AI 听并校准",
    goal: "用自己的话重建整套概念",
    method: "费曼模式或苏格拉底模式",
    doneWhen: "能讲清概念、举例并回应一次追问",
    duration: "12 分钟",
    status: "queued",
  },
];

const LANGUAGE_OPTIONS = [
  { id: "zh", label: "中文", locale: "zh-CN" },
  { id: "en", label: "English", locale: "en-US" },
  { id: "ja", label: "日本語", locale: "ja-JP" },
  { id: "ko", label: "한국어", locale: "ko-KR" },
];

const LANGUAGE_COPY = {
  zh: {
    nav: ["产品能力", "学习方法", "精选领域"],
    note: "带着一个问题来",
    login: "登录 / 注册",
    heroTag: "学会一个概念，而不是看完一段回答",
    heroTitleA: "把新知识放上桌，",
    heroTitleB: "一步一步",
    heroTitleAccent: "真正学会",
    heroCopy: "导入任何学习资料，AI 会先整理学习路径，再用简单讲解、掌握检查、费曼复述和苏格拉底追问，陪你把陌生概念变成自己的知识。",
    start: "开始我的学习",
    demo: "直接体验 Demo",
    proofs: ["自带 API Key", "记录学习轨迹", "文字优先，保留语音"],
    daily: "今天也可以只学会一个小概念。",
    prompt: "今天想弄懂什么？",
    authTag: "仅支持邮箱登录",
    authTitle: "继续你的学习旅程",
    signupTitle: "建立你的数字书桌",
    authCopy: "登录后可保存学习路径、掌握度、认知校准档案和个人学习画像。",
    email: "邮箱",
    password: "密码",
    remember: "记住我",
    submit: "登录",
    signup: "创建账号",
  },
  en: {
    nav: ["What it does", "How it works", "Topics"],
    note: "Bring one good question",
    login: "Sign in",
    heroTag: "Learn a concept—not just read an answer",
    heroTitleA: "Put new knowledge on your desk.",
    heroTitleB: "Learn it ",
    heroTitleAccent: "step by step",
    heroCopy: "Bring any learning material. AI turns it into a clear path, explains one idea at a time, checks your understanding, and guides Feynman teach-backs and Socratic questioning.",
    start: "Start learning",
    demo: "Try the demo",
    proofs: ["Bring your own API key", "Keep a learning history", "Text first, voice ready"],
    daily: "One small concept is enough for today.",
    prompt: "What do you want to understand?",
    authTag: "Email sign-in only",
    authTitle: "Continue your learning journey",
    signupTitle: "Create your digital desk",
    authCopy: "Sign in to save learning paths, mastery, calibration notes, and your learner profile.",
    email: "Email",
    password: "Password",
    remember: "Remember me",
    submit: "Sign in",
    signup: "Create account",
  },
  ja: {
    nav: ["できること", "学び方", "学習テーマ"],
    note: "ひとつの疑問から始めよう",
    login: "ログイン",
    heroTag: "答えを読むだけでなく、概念を身につける",
    heroTitleA: "新しい知識を机の上へ。",
    heroTitleB: "一歩ずつ",
    heroTitleAccent: "自分の知識に",
    heroCopy: "学習資料を取り込むと、AIが学習ルートを整理し、やさしい説明、理解チェック、ファインマン式の説明、ソクラテス式の問いかけで学びを支えます。",
    start: "学習を始める",
    demo: "デモを体験",
    proofs: ["自分の API Key", "学習履歴を保存", "文字入力を優先"],
    daily: "今日は小さな概念をひとつ。",
    prompt: "今日は何を理解したい？",
    authTag: "メールログインのみ",
    authTitle: "学習を続ける",
    signupTitle: "デジタル学習机をつくる",
    authCopy: "ログインすると、学習ルート、習熟度、理解の記録、学習プロフィールを保存できます。",
    email: "メール",
    password: "パスワード",
    remember: "ログインを保持",
    submit: "ログイン",
    signup: "アカウント作成",
  },
  ko: {
    nav: ["제품 기능", "학습 방식", "추천 분야"],
    note: "좋은 질문 하나로 시작하세요",
    login: "로그인",
    heroTag: "답을 읽는 데서 끝내지 말고, 개념을 내 것으로",
    heroTitleA: "새로운 지식을 책상 위에.",
    heroTitleB: "한 단계씩 ",
    heroTitleAccent: "제대로 배우기",
    heroCopy: "어떤 학습 자료든 가져오세요. AI가 학습 경로를 정리하고, 쉬운 설명과 이해 점검, 파인만 복습, 소크라테스식 질문으로 학습을 안내합니다.",
    start: "학습 시작",
    demo: "데모 체험",
    proofs: ["내 API Key 사용", "학습 기록 저장", "텍스트 우선, 음성 준비"],
    daily: "오늘은 작은 개념 하나면 충분해요.",
    prompt: "오늘 무엇을 이해하고 싶나요?",
    authTag: "이메일 로그인만 지원",
    authTitle: "학습 여정 이어가기",
    signupTitle: "나만의 디지털 책상 만들기",
    authCopy: "로그인하면 학습 경로, 이해도, 인지 교정 기록과 학습 프로필을 저장할 수 있습니다.",
    email: "이메일",
    password: "비밀번호",
    remember: "로그인 유지",
    submit: "로그인",
    signup: "계정 만들기",
  },
};

function readStorage(key, fallback) {
  try {
    const value = window.localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // The prototype remains usable when local storage is unavailable.
  }
}

function Logo({ compact = false }) {
  return (
    <button className="brand" type="button" aria-label="返回首页">
      <span className="brand-mark">
        <Sparkle size={compact ? 17 : 20} weight="fill" />
      </span>
      {!compact && <span>Learn New</span>}
    </button>
  );
}

function LanguagePicker({ value, onChange, compact = false }) {
  return (
    <label className={`language-picker ${compact ? "compact" : ""}`}>
      <span>文 / A</span>
      <select value={value} onChange={(event) => onChange(event.target.value)} aria-label="选择界面语言">
        {LANGUAGE_OPTIONS.map((language) => (
          <option value={language.id} key={language.id}>{language.label}</option>
        ))}
      </select>
    </label>
  );
}

function Tag({ children, tone = "lavender" }) {
  return <span className={`tag tag-${tone}`}>{children}</span>;
}

function MasteryRing({ value, size = "large" }) {
  return (
    <div
      className={`mastery-ring mastery-${size}`}
      style={{ "--progress": `${Math.max(0, Math.min(value, 100)) * 3.6}deg` }}
      aria-label={`当前掌握度 ${value}%`}
    >
      <div className="mastery-ring-inner">
        <strong>{value}%</strong>
        <span>掌握度</span>
      </div>
    </div>
  );
}

const WEEKDAY_GUIDANCE = {
  0: "周日适合轻松回顾，把这一周的零散想法串成线。",
  1: "周一适合搭建全局框架，先看地图再进入细节。",
  2: "周二适合啃一个难概念，让问题带着你往深处走。",
  3: "周三适合做一次中途校准，检查哪些地方只是“看懂了”。",
  4: "周四适合迁移应用，把概念放进一个真实问题里。",
  5: "周五适合复述总结，用自己的话给这一周收个尾。",
  6: "周六适合跟随好奇心，随手打开一个陌生领域。",
};

function getDateContext() {
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 6 ? "夜深了" : hour < 11 ? "早上好" : hour < 14 ? "中午好" : hour < 18 ? "下午好" : "晚上好";
  const weekday = now.toLocaleDateString("zh-CN", { weekday: "long" });
  const fullDate = now.toLocaleDateString("zh-CN", { year: "numeric", month: "long", day: "numeric" });
  const month = now.toLocaleDateString("zh-CN", { month: "long" });
  return { now, greeting, weekday, fullDate, month, guidance: WEEKDAY_GUIDANCE[now.getDay()] };
}

function AppHeader({
  session,
  apiConnected,
  onLogo,
  onLogin,
  onNavigate,
  onLogout,
  language,
  onLanguage,
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const copy = LANGUAGE_COPY[language] || LANGUAGE_COPY.zh;

  return (
    <header className={`app-header ${session ? "signed-header" : "public-header"}`}>
      <div onClick={onLogo}>
        <Logo />
      </div>
      {!session && (
        <nav className="top-nav public-nav" aria-label="官网导航">
          <a href="#capabilities">{copy.nav[0]}</a>
          <a href="#method">{copy.nav[1]}</a>
          <a href="#domains">{copy.nav[2]}</a>
        </nav>
      )}
      <div className="header-actions">
        <LanguagePicker value={language} onChange={onLanguage} compact={Boolean(session)} />
        {session ? (
          <>
            <button
              className={`api-status ${apiConnected ? "connected" : ""}`}
              type="button"
              onClick={() => onNavigate("settings")}
            >
              <Key size={17} />
              <span>{apiConnected ? "AI 已连接" : "连接 AI"}</span>
              <span className="status-dot" />
            </button>
            <div className="profile-menu-wrap">
              <button
                className="profile-trigger"
                type="button"
                onClick={() => setMenuOpen((open) => !open)}
                aria-expanded={menuOpen}
              >
                <span className="avatar">LX</span>
                <span className="profile-copy">
                  <strong>{session.name}</strong>
                  <small>持续学习第 12 天</small>
                </span>
                <CaretDown size={15} />
              </button>
              {menuOpen && (
                <div className="profile-menu">
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate("settings");
                      setMenuOpen(false);
                    }}
                  >
                    <Gear size={18} />
                    个人设置
                  </button>
                  <button
                    className="menu-logout"
                    type="button"
                    onClick={() => {
                      onLogout();
                      setMenuOpen(false);
                    }}
                  >
                    <SignOut size={18} />
                    退出登录
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <span className="public-header-note">{copy.note}</span>
            <button className="button button-primary button-small" onClick={onLogin} type="button">
              {copy.login}
            </button>
          </>
        )}
      </div>
    </header>
  );
}

function Landing({ onLogin, onDemo, language }) {
  const copy = LANGUAGE_COPY[language] || LANGUAGE_COPY.zh;
  const date = getDateContext();
  const locale = LANGUAGE_OPTIONS.find((item) => item.id === language)?.locale || "zh-CN";
  const calendarDays = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(date.now);
    day.setDate(date.now.getDate() - 3 + index);
    return day;
  });

  return (
    <main className="landing">
      <section className="hero">
        <div className="hero-copy">
          <Tag tone="pink">
            <Sparkle size={14} weight="fill" />
             {copy.heroTag}
          </Tag>
          <h1>
            {copy.heroTitleA}
            <br />
            {copy.heroTitleB}<span>{copy.heroTitleAccent}</span>
          </h1>
          <p>
            {copy.heroCopy}
          </p>
          <div className="hero-actions">
            <button className="button button-primary button-large" type="button" onClick={onLogin}>
              {copy.start}
              <ArrowRight size={18} weight="bold" />
            </button>
            <button className="button button-ghost button-large" type="button" onClick={onDemo}>
              <Compass size={19} />
              {copy.demo}
            </button>
          </div>
          <div className="hero-proof">
            <span>
               <CheckCircle size={16} weight="fill" /> {copy.proofs[0]}
            </span>
            <span>
               <CheckCircle size={16} weight="fill" /> {copy.proofs[1]}
            </span>
            <span>
               <CheckCircle size={16} weight="fill" /> {copy.proofs[2]}
            </span>
          </div>
        </div>
        <div className="public-daily-card" aria-label="今日学习日历">
          <div className="daily-topline">
            <span><CalendarBlank size={18} /> {date.fullDate}</span>
            <Tag tone="pink">{date.weekday}</Tag>
          </div>
          <div className="daily-greeting">
            <span>{date.greeting}</span>
            <h2>{copy.daily}</h2>
            <p>{date.guidance}</p>
          </div>
          <div className="week-calendar">
            {calendarDays.map((day) => {
              const active = day.toDateString() === date.now.toDateString();
              return (
                <div className={active ? "active" : ""} key={day.toISOString()}>
                  <small>{day.toLocaleDateString(locale, { weekday: "short" }).replace("周", "")}</small>
                  <strong>{day.getDate()}</strong>
                  <i />
                </div>
              );
            })}
          </div>
          <button type="button" className="daily-prompt" onClick={onDemo}>
             <span><Sparkle size={18} weight="fill" /> {copy.prompt}</span>
            <ArrowRight size={18} />
          </button>
        </div>
      </section>
      <section className="public-intro" id="capabilities">
        <div className="section-heading centered">
          <div>
            <span className="eyebrow">它能为你做什么</span>
            <h2>不是再多看一遍，而是把知识变成自己的话</h2>
            <p>从一份资料、一本书或一个好奇的问题出发，AI 把学习过程拆成清晰步骤。</p>
          </div>
        </div>
        <div className="capability-grid">
          <article><span><MapTrifold size={24} /></span><strong>先搭学习地图</strong><p>先看到概念全貌、先后关系和预计时间，再决定从哪里开始。</p></article>
          <article><span><BookOpen size={24} /></span><strong>每次只讲一点</strong><p>简单讲解之后马上检查理解，不让“我看懂了”蒙混过关。</p></article>
          <article><span><Brain size={24} /></span><strong>换你来当老师</strong><p>费曼复述和苏格拉底追问交替，让模糊处自然暴露出来。</p></article>
        </div>
      </section>
      <section className="method-strip" id="method">
        <article>
          <span>01</span>
          <div>
            <strong>先看全局</strong>
            <p>AI 从资料中整理学习地图，告诉你概念之间的关系。</p>
          </div>
        </article>
        <article>
          <span>02</span>
          <div>
            <strong>再讲简单</strong>
            <p>每次只讲一个知识点，确认理解后再继续。</p>
          </div>
        </article>
        <article>
          <span>03</span>
          <div>
            <strong>最后讲给 AI 听</strong>
            <p>用复述和追问暴露盲区，形成真正稳定的理解。</p>
          </div>
        </article>
      </section>
      <section className="public-domains" id="domains">
        <div>
          <span className="eyebrow">精选领域</span>
          <h2>从好奇心开始，不限定学科</h2>
          <p>心理学、AI 智能体、经济学、批判性思维、沟通与谈判、数据素养……登录后进入完整领域书架，也可以上传自己的资料。</p>
        </div>
        <div className="domain-pills">
          {knowledgePacks.slice(0, 8).map((pack) => <span key={pack.id}>{pack.title}</span>)}
        </div>
      </section>
    </main>
  );
}

function AuthModal({ onClose, onSuccess, onDemo, language }) {
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const copy = LANGUAGE_COPY[language] || LANGUAGE_COPY.zh;

  const submit = (event) => {
    event.preventDefault();
    setLoading(true);
    window.setTimeout(() => {
      onSuccess({
        name: email ? email.split("@")[0] : "Lia Xuan",
        email: email || "liaxuan@example.com",
      });
      setLoading(false);
    }, 650);
  };

  return (
    <div className="modal-backdrop" role="presentation">
      <section className="auth-modal" role="dialog" aria-modal="true" aria-label="登录">
        <button className="modal-close" type="button" onClick={onClose} aria-label="关闭">
          <X size={20} />
        </button>
        <div className="auth-brand">
          <Logo />
          <Tag tone="lavender">{copy.authTag}</Tag>
        </div>
        <h2>{mode === "login" ? copy.authTitle : copy.signupTitle}</h2>
        <p>{copy.authCopy}</p>
        <form onSubmit={submit}>
          <label>
            {copy.email}
            <input
              required
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="name@example.com"
            />
          </label>
          <label>
            {copy.password}
            <input
              required
              minLength={4}
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="至少 4 位字符"
            />
          </label>
          <div className="form-row">
            <label className="check-label">
              <input type="checkbox" defaultChecked />
               <span>{copy.remember}</span>
            </label>
            <button type="button" className="text-button">
              忘记密码？
            </button>
          </div>
          <button className="button button-primary button-full" type="submit" disabled={loading}>
            {loading ? <CircleNotch className="spin" size={20} /> : null}
            {mode === "login" ? copy.submit : copy.signup}
          </button>
        </form>
        <div className="auth-divider">
          <span>或者</span>
        </div>
        <button
          className="button button-soft button-full"
          type="button"
          onClick={onDemo}
        >
          <Sparkle size={18} weight="fill" />
          使用演示账号进入
        </button>
        <p className="auth-switch">
          {mode === "login" ? "第一次来？" : "已经有账号？"}
          <button type="button" onClick={() => setMode(mode === "login" ? "signup" : "login")}>
            {mode === "login" ? "创建账号" : "直接登录"}
          </button>
        </p>
      </section>
    </div>
  );
}

function OnboardingTour({ onFinish }) {
  const [step, setStep] = useState(0);
  const items = [
    { icon: House, label: "今日桌面", title: "先看看今天适合怎么学", copy: "这里放着你的日历、继续学习和一条不费力的今日建议。" },
    { icon: Books, label: "领域书架", title: "再选择一个想弄懂的领域", copy: "可以直接打开预置知识包，也可以上传教材、论文、讲义或笔记。" },
    { icon: MapTrifold, label: "学习空间", title: "沿着一条清晰路径学习", copy: "资料 → 学习地图 → 简单讲解 → 理解检查 → 深度学习，当前位置始终可见。" },
    { icon: ChartBar, label: "学习中心", title: "最后回看你的变化", copy: "学习历史、当前薄弱环节、认知校准档案和学习画像都集中在这里。" },
  ];
  const item = items[step];
  const Icon = item.icon;

  return (
    <div className="modal-backdrop tour-backdrop" role="presentation">
      <section className="tour-modal" role="dialog" aria-modal="true" aria-label="新手引导">
        <div className="tour-preview">
          <span className="tour-icon"><Icon size={30} weight="duotone" /></span>
          <Tag tone="pink">{item.label}</Tag>
          <div className="tour-dots">{items.map((entry, index) => <i className={index === step ? "active" : ""} key={entry.label} />)}</div>
        </div>
        <div className="tour-copy">
          <span className="eyebrow">欢迎来到你的数字书桌 · {step + 1} / {items.length}</span>
          <h2>{item.title}</h2>
          <p>{item.copy}</p>
          <div className="tour-route">
            {items.map((entry, index) => (
              <span className={index === step ? "active" : index < step ? "done" : ""} key={entry.label}>
                {index < step ? <Check size={13} /> : index + 1} {entry.label}
              </span>
            ))}
          </div>
          <div className="setup-actions">
            <button className="button button-ghost" type="button" onClick={onFinish}>跳过引导</button>
            <button
              className="button button-primary"
              type="button"
              onClick={() => step === items.length - 1 ? onFinish() : setStep((value) => value + 1)}
            >
              {step === items.length - 1 ? "完成引导" : "下一步"} <ArrowRight size={17} />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}

function AIConnectionModal({ initialKey, selectedPack, onClose, onConnect, onDemo }) {
  const [key, setKey] = useState(initialKey || "");
  return (
    <div className="modal-backdrop setup-backdrop" role="presentation">
      <section className="setup-modal ai-connect-modal" role="dialog" aria-modal="true" aria-label="连接 AI">
        <button className="modal-close" type="button" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <div className="setup-heading">
          <span className="setup-icon"><Key size={25} weight="duotone" /></span>
          <div>
            <Tag tone="lavender">开始「{selectedPack?.title || "新学习"}」前</Tag>
            <h2>连接你的 AI</h2>
            <p>真实分析和互动需要你自己的 API Key；也可以先用演示内容完整走一遍流程。</p>
          </div>
        </div>
        <label className="key-field">
          API Key
          <div>
            <LockKey size={19} />
            <input type="password" value={key} onChange={(event) => setKey(event.target.value)} placeholder="sk-••••••••••••••••" />
            <Tag tone={key ? "green" : "lavender"}>{key ? "待连接" : "仅存本地"}</Tag>
          </div>
        </label>
        <div className="privacy-note">
          <ShieldCheck size={20} weight="fill" />
          <span>原型仅保存在当前浏览器。正式产品会提供更严格的加密与供应商说明。</span>
        </div>
        <div className="setup-actions">
          <button className="button button-ghost" type="button" onClick={onDemo}>先体验演示</button>
          <button className="button button-primary" type="button" disabled={!key.trim()} onClick={() => onConnect(key.trim())}>
            连接并开始 <ArrowRight size={17} />
          </button>
        </div>
      </section>
    </div>
  );
}

function Desk({ session, onStart, onOpenWorkspace, onNavigate }) {
  const date = getDateContext();
  const [briefTab, setBriefTab] = useState("趣事");
  const briefing = {
    趣事: {
      eyebrow: "心理学小趣事",
      title: "越容易想起的事，我们越容易高估它发生的概率",
      copy: "这叫“可得性启发”。下次看到一个令人印象深刻的案例，可以顺手问自己：它真的常见，还是只是更容易被记住？",
      action: "把它加入今日思考",
    },
    动态: {
      eyebrow: "AI 今日观察",
      title: "Agent 的重点，不只是会聊天",
      copy: "规划步骤、调用工具、读取结果并继续修正，才构成一段完整的智能体工作流。可以从“它替我完成了哪条闭环”来判断价值。",
      action: "去学习 AI 智能体",
    },
    灵感: {
      eyebrow: "学习方法灵感",
      title: "把概念讲一遍，比再看一遍更容易发现空白",
      copy: "如果某一句突然讲不下去，那不是失败，而是最有价值的信号：你刚刚找到了需要继续澄清的位置。",
      action: "开始一次费曼复述",
    },
  };
  const activeBrief = briefing[briefTab];
  const week = Array.from({ length: 7 }, (_, index) => {
    const day = new Date(date.now);
    day.setDate(date.now.getDate() - date.now.getDay() + index);
    return day;
  });
  return (
    <main className="page desk-page">
      <section className="desk-greeting">
        <div>
          <Tag tone="pink">{date.weekday} · {date.month}</Tag>
          <h1>{date.greeting}，{session?.name || "学习者"}</h1>
          <p>今天想把哪个陌生概念，变成你能讲清楚的知识？</p>
        </div>
        <button className="button button-primary button-large" type="button" onClick={onStart}>
          <Books size={18} weight="bold" />
          去领域书架
        </button>
      </section>

      <section className="desk-date-card">
        <div className="desk-week">
          {week.map((day) => {
            const active = day.toDateString() === date.now.toDateString();
            return (
              <div className={active ? "active" : ""} key={day.toISOString()}>
                <small>{day.toLocaleDateString("zh-CN", { weekday: "short" })}</small>
                <strong>{day.getDate()}</strong>
              </div>
            );
          })}
        </div>
        <div className="weekday-guide">
          <span><Sparkle size={19} weight="fill" /></span>
          <div><small>今日学习提示</small><strong>{date.guidance}</strong></div>
        </div>
      </section>

      <section className="daily-briefing">
        <div className="briefing-rail">
          <div>
            <span className="eyebrow">今日知识播报</span>
            <h2>给好奇心一点新鲜素材</h2>
          </div>
          <nav aria-label="今日播报分类">
            {Object.keys(briefing).map((item) => (
              <button className={briefTab === item ? "active" : ""} type="button" key={item} onClick={() => setBriefTab(item)}>
                {item === "趣事" ? "小趣事" : item === "动态" ? "AI 动态" : "学习灵感"}
              </button>
            ))}
          </nav>
        </div>
        <article className="briefing-story">
          <span><Sparkle size={21} weight="fill" /></span>
          <div>
            <small>{activeBrief.eyebrow} · 今日推荐</small>
            <h3>{activeBrief.title}</h3>
            <p>{activeBrief.copy}</p>
          </div>
          <button type="button" onClick={() => briefTab === "动态" ? onStart("ai-agents") : onOpenWorkspace()}>
            {activeBrief.action} <ArrowRight size={15} />
          </button>
        </article>
        <small className="briefing-note">演示版为精选内容；正式版可按学习领域接入实时知识资讯。</small>
      </section>

      <section className="desk-grid">
        <article className="continue-card">
          <div className="card-title-row">
            <div>
              <span className="eyebrow">继续学习</span>
              <h2>双系统思维</h2>
              <p>心理学 · 已完成 3 / 8 个概念</p>
            </div>
            <MasteryRing value={36} size="medium" />
          </div>
          <div className="mini-journey">
            {["资料", "地图", "讲解", "检查", "深度"].map((item, index) => (
              <div className={index < 2 ? "complete" : index === 2 ? "current" : ""} key={item}>
                <span>{index < 2 ? <Check size={12} weight="bold" /> : index + 1}</span>
                <small>{item}</small>
              </div>
            ))}
          </div>
          <div className="continue-footer">
            <div>
              <Lightbulb size={20} weight="fill" />
              <span>
                下一步
                <strong>系统 1：快速判断是如何发生的？</strong>
              </span>
            </div>
            <button className="button button-primary" type="button" onClick={onOpenWorkspace}>
              继续学习 <ArrowRight size={16} />
            </button>
          </div>
        </article>

        <aside className="today-card">
          <span className="eyebrow">今天的节奏</span>
          <strong className="big-number">18</strong>
          <span className="big-number-unit">分钟专注学习</span>
          <div className="today-stat">
            <Target size={20} />
            <div>
              <strong>1 个概念已讲清</strong>
              <span>比昨天多 1 个</span>
            </div>
          </div>
          <div className="today-stat">
            <SealCheck size={20} />
            <div>
              <strong>连续学习 12 天</strong>
              <span>正在形成你的节奏</span>
            </div>
          </div>
        </aside>
      </section>

      <section className="section-heading">
        <div>
          <span className="eyebrow">精选知识包</span>
          <h2>从一个感兴趣的问题开始</h2>
        </div>
        <button className="text-button with-icon" type="button" onClick={() => onNavigate("library")}>
          打开领域书架 <ArrowRight size={15} />
        </button>
      </section>
      <section className="pack-grid">
        {knowledgePacks.slice(0, 3).map((pack, index) => (
          <article className={`pack-card pack-${pack.accent}`} key={pack.id}>
            <div className="pack-icon">
              {index === 0 ? <Brain size={24} /> : index === 1 ? <ChartBar size={24} /> : <Compass size={24} />}
            </div>
            <Tag tone={pack.accent}>{pack.title}</Tag>
            <h3>{pack.subtitle}</h3>
            <p>{pack.meta}</p>
            <button type="button" onClick={() => onStart(pack.id)}>
              打开知识包 <ArrowRight size={16} />
            </button>
          </article>
        ))}
      </section>

      <section className="desk-bottom-grid">
        <article className="calibration-preview">
          <div className="card-title-row compact">
            <div>
              <span className="eyebrow">认知校准档案</span>
              <h2>把模糊处留在案头</h2>
            </div>
            <button className="icon-button" type="button" onClick={() => onNavigate("center")}>
              <ArrowRight size={18} />
            </button>
          </div>
          {calibrationItems.slice(0, 2).map((item) => (
            <div className="calibration-row" key={item.title}>
              <span className={item.type === "已校准" ? "good" : ""}>
                {item.type === "已校准" ? <Check size={15} /> : <Question size={15} />}
              </span>
              <div>
                <strong>{item.title}</strong>
                <p>{item.detail}</p>
              </div>
              <Tag tone={item.type === "已校准" ? "green" : "peach"}>{item.type}</Tag>
            </div>
          ))}
        </article>
        <article className="learning-profile-preview">
          <span className="eyebrow">你的学习画像</span>
          <h2>你擅长从例子开始理解</h2>
          <p>先看到真实场景，再抽象概念，会让你的掌握速度提升约 23%。</p>
          <div className="profile-bars">
            <label>
              <span>例子联想</span>
              <i><b style={{ width: "86%" }} /></i>
            </label>
            <label>
              <span>概念复述</span>
              <i><b style={{ width: "72%" }} /></i>
            </label>
            <label>
              <span>连续推理</span>
              <i><b style={{ width: "58%" }} /></i>
            </label>
          </div>
          <button className="text-button with-icon" type="button" onClick={() => onNavigate("center")}>
            查看完整画像 <CaretRight size={15} />
          </button>
        </article>
      </section>
    </main>
  );
}

function Library({ onSelectPack, onUpload }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("全部");
  const inputRef = useRef(null);
  const categories = ["全部", ...new Set(knowledgePacks.map((pack) => pack.category))];
  const visiblePacks = knowledgePacks.filter((pack) => {
    const categoryMatch = category === "全部" || pack.category === category;
    const text = `${pack.title}${pack.subtitle}${pack.category}`.toLowerCase();
    return categoryMatch && text.includes(query.trim().toLowerCase());
  });
  const discoveryPrompts = [
    { pack: knowledgePacks.find((item) => item.id === "ai-agents"), question: "AI 智能体为什么不只是聊天机器人？", tone: "lavender" },
    { pack: knowledgePacks.find((item) => item.id === "behavioral-economics"), question: "为什么“免费”会让人改变原本的判断？", tone: "peach" },
    { pack: knowledgePacks.find((item) => item.id === "systems-thinking"), question: "为什么解决一个问题，有时会制造另一个问题？", tone: "pink" },
  ].filter((item) => item.pack);

  return (
    <main className="page library-page">
      <section className="library-hero">
        <div>
          <Tag tone="pink"><Books size={15} /> 领域书架</Tag>
          <h1>今天，想进入哪个新领域？</h1>
          <p>先选一个知识包，或者把自己的教材、论文、讲义放上书桌。系统会在开始前带你完成 AI 配置。</p>
        </div>
        <button className="button button-primary button-large" type="button" onClick={() => inputRef.current?.click()}>
          <UploadSimple size={18} weight="bold" /> 上传我的资料
        </button>
        <input
          className="visually-hidden"
          ref={inputRef}
          type="file"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) onUpload(file);
          }}
        />
      </section>

      <section className="library-toolbar">
        <div className="library-search-row">
          <label className="library-search">
            <MagnifyingGlass size={18} />
            <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索领域或概念" />
          </label>
          <span>{knowledgePacks.length} 个主题 · {categories.length - 1} 类领域 · 支持自有资料</span>
        </div>
        <div className="filter-row">
          <span><SlidersHorizontal size={18} /> 按领域筛选</span>
          <div className="category-filter">
            {categories.map((item) => (
              <button className={category === item ? "active" : ""} type="button" key={item} onClick={() => setCategory(item)}>{item}</button>
            ))}
          </div>
        </div>
      </section>

      {category === "全部" && !query && (
        <section className="discovery-shelf">
          <div className="shelf-heading">
            <div><span className="eyebrow">今天适合探索</span><h2>也可以从一个问题开始</h2></div>
            <span>3 个好奇心入口</span>
          </div>
          <div className="discovery-grid">
            {discoveryPrompts.map(({ pack, question, tone }, index) => (
              <article className={`discovery-card ${tone}`} key={pack.id}>
                <span>0{index + 1}</span>
                <div><small>{pack.category} · {pack.level}</small><h3>{question}</h3><p>{pack.meta}</p></div>
                <button type="button" aria-label={`开始学习${pack.title}`} onClick={() => onSelectPack(pack)}><ArrowRight size={17} /></button>
              </article>
            ))}
          </div>
        </section>
      )}

      <section className="shelf-section">
        <div className="shelf-heading">
          <div><span className="eyebrow">预置知识包</span><h2>{category === "全部" ? "为好奇心准备的一整面书架" : category}</h2></div>
          <span>{visiblePacks.length} 本可学习</span>
        </div>
        <div className="book-shelf">
          {visiblePacks.map((pack, index) => {
            const Icon = [Brain, ChartBar, Compass, Sparkle, TrendUp, Question][index % 6];
            return (
              <article className={`book-card book-${pack.accent}`} key={pack.id}>
                <div className="book-cover">
                  <span className="book-category">{pack.category}</span>
                  <Icon size={30} weight="duotone" />
                  <div><small>{pack.level}</small><h3>{pack.title}</h3></div>
                  <i />
                </div>
                <div className="book-info">
                  <p>{pack.subtitle}</p>
                  <div className="book-highlights">
                    <span>学习路径</span><span>生活例子</span><span>互动复述</span>
                  </div>
                  <span>{pack.meta}</span>
                  <button type="button" onClick={() => onSelectPack(pack)}>开始学习 <ArrowRight size={15} /></button>
                </div>
              </article>
            );
          })}
        </div>
        {visiblePacks.length === 0 && <div className="library-empty"><Books size={30} /><strong>这层书架暂时没有结果</strong><span>换一个关键词，或上传自己的资料开始。</span></div>}
      </section>

      <section className="upload-shelf" onClick={() => inputRef.current?.click()}>
        <span><Plus size={25} /></span>
        <div><strong>没有找到想学的？自己放一本上来</strong><p>支持教材、论文、PDF、文档、笔记等资料。演示版先展示上传入口与完整学习流程。</p></div>
        <button className="button button-soft" type="button">选择文件</button>
      </section>
    </main>
  );
}

function AppSidebar({ page, onNavigate }) {
  const items = [
    { id: "desk", label: "今日桌面", copy: "问候与继续学习", icon: House },
    { id: "library", label: "领域书架", copy: "选知识包或上传", icon: Books },
    { id: "workspace", label: "学习空间", copy: "地图与互动学习", icon: MapTrifold },
    { id: "center", label: "学习中心", copy: "记录、薄弱点与画像", icon: ChartBar },
  ];
  return (
    <aside className="app-sidebar">
      <span className="sidebar-eyebrow">你的学习路径</span>
      <nav aria-label="应用主导航">
        {items.map((item, index) => {
          const Icon = item.icon;
          return (
            <button className={page === item.id ? "active" : ""} type="button" key={item.id} onClick={() => onNavigate(item.id)}>
              <span className="sidebar-index">{index + 1}</span>
              <Icon size={19} weight={page === item.id ? "fill" : "regular"} />
              <span><strong>{item.label}</strong><small>{item.copy}</small></span>
              <CaretRight size={15} />
            </button>
          );
        })}
      </nav>
      <div className="sidebar-help">
        <Sparkle size={18} weight="fill" />
        <div><strong>第一次使用？</strong><span>按 1 → 4 的顺序走，就不会迷路。</span></div>
      </div>
    </aside>
  );
}

function StageNav({ activeStage, onChange }) {
  const activeIndex = STAGES.findIndex((item) => item.id === activeStage);
  return (
    <nav className="stage-nav" aria-label="学习阶段">
      {STAGES.map((stage, index) => {
        const Icon = stage.icon;
        const completed = index < activeIndex;
        return (
          <button
            key={stage.id}
            type="button"
            className={`${stage.id === activeStage ? "active" : ""} ${completed ? "completed" : ""}`}
            onClick={() => onChange(stage.id)}
          >
            <span>
              {completed ? <Check size={15} weight="bold" /> : <Icon size={18} weight={stage.id === activeStage ? "fill" : "regular"} />}
            </span>
            <div><strong>{stage.label}</strong><small>{stage.copy}</small></div>
            {index < STAGES.length - 1 && <i />}
          </button>
        );
      })}
    </nav>
  );
}

function SourceDrawer({ uploadedFile, onUpload, compact = false }) {
  const inputRef = useRef(null);
  return (
    <aside className={`source-drawer ${compact ? "compact" : ""}`}>
      <div className="drawer-heading">
        <span className="eyebrow">我的资料</span>
        <button className="icon-button" type="button" aria-label="添加资料" onClick={() => inputRef.current?.click()}>
          <Plus size={17} />
        </button>
      </div>
      <input
        ref={inputRef}
        className="visually-hidden"
        type="file"
        accept="*/*"
        onChange={(event) => event.target.files?.[0] && onUpload(event.target.files[0])}
      />
      <div className="source-file active">
        {uploadedFile ? <FileText size={20} weight="fill" /> : <FilePdf size={20} weight="fill" />}
        <div>
          <strong>{uploadedFile?.name || "思考，快与慢.pdf"}</strong>
          <span>{uploadedFile ? "本地资料 · 已就绪" : "PDF · 2.4 MB"}</span>
        </div>
        <CheckCircle size={18} weight="fill" />
      </div>
      {!compact && (
        <>
          <span className="eyebrow drawer-subtitle">精选知识包</span>
          {knowledgePacks.map((pack) => (
            <button className="drawer-pack" type="button" key={pack.id}>
              <BookOpen size={18} />
              <span>
                <strong>{pack.title}</strong>
                <small>{pack.meta.split(" · ")[0]}</small>
              </span>
              <CaretRight size={15} />
            </button>
          ))}
          <button className="upload-dashed" type="button" onClick={() => inputRef.current?.click()}>
            <UploadSimple size={18} />
            导入新资料
          </button>
        </>
      )}
      {compact && (
        <div className="compact-excerpts">
          <span className="eyebrow">相关摘录</span>
          <article>
            <b>01</b>
            <p>系统 1 持续自动运行，系统 2 通常处于低努力状态。</p>
          </article>
          <article>
            <b>02</b>
            <p>注意力被占用时，我们更容易依赖直觉判断。</p>
          </article>
          <article>
            <b>03</b>
            <p>熟练经验能让系统 1 形成有效、快速的专业直觉。</p>
          </article>
        </div>
      )}
    </aside>
  );
}

function ProgressAside({ mastery, stage, onNavigate, onViewPath }) {
  return (
    <aside className="progress-aside">
      <section className="mastery-card">
        <div className="card-title-row compact">
          <strong>当前掌握度</strong>
          <Question size={16} />
        </div>
        <MasteryRing value={mastery} size="medium" />
        <p>{mastery < 50 ? "仍需巩固 · 慢慢来" : "理解正在变得稳定"}</p>
        {stage === "deep" && (
          <div className="mastery-breakdown">
            <label>
              <span>概念边界</span>
              <i><b style={{ width: "80%" }} /></i>
              <strong>80%</strong>
            </label>
            <label>
              <span>例子迁移</span>
              <i><b style={{ width: "68%" }} /></i>
              <strong>68%</strong>
            </label>
            <label>
              <span>连续推理</span>
              <i><b style={{ width: "55%" }} /></i>
              <strong>55%</strong>
            </label>
          </div>
        )}
      </section>
      <section className="map-progress-card">
        <div className="card-title-row compact">
          <span>
            <MapTrifold size={18} />
            本次学习路径
          </span>
          <button type="button" onClick={onViewPath}>查看</button>
        </div>
        <strong>{stage === "deep" ? "6" : stage === "lesson" || stage === "check" ? "2" : "1"} / 6</strong>
        <span>个学习步骤</span>
        <div className="linear-progress">
          <i style={{ width: stage === "deep" ? "100%" : stage === "lesson" || stage === "check" ? "34%" : "17%" }} />
        </div>
      </section>
      <section className="calibration-aside">
        <div className="card-title-row compact">
          <strong>认知校准档案</strong>
          <FileText size={17} />
        </div>
        <div className="aside-observation">
          <span />
          <p>区分系统 1 与系统 2 时，记得说明两者并非“错误”与“正确”的关系。</p>
        </div>
        <button type="button" onClick={() => onNavigate("center")}>
          查看档案 <ArrowRight size={15} />
        </button>
      </section>
      <div className="aside-links">
        <button type="button" onClick={() => onNavigate("center")}>
          <ClockCounterClockwise size={18} />
          学习历史
          <CaretRight size={15} />
        </button>
        <button type="button" onClick={() => onNavigate("center")}>
          <User size={18} />
          学习画像
          <CaretRight size={15} />
        </button>
      </div>
    </aside>
  );
}

function MaterialsStage({ uploadedFile, onUpload, onGenerate, analyzing }) {
  const inputRef = useRef(null);
  const [selectedPack, setSelectedPack] = useState("psychology");

  return (
    <section className="materials-stage">
      <div className="workspace-heading">
        <div>
          <Tag tone="pink">第一步 · 准备资料</Tag>
          <h1>今天想学什么？</h1>
          <p>上传一份自己的资料，或直接使用预置知识包。AI 会把内容整理成一条可以照着走的学习路径。</p>
        </div>
      </div>
      <div className="materials-grid">
        <button className="big-upload" type="button" onClick={() => inputRef.current?.click()}>
          <input
            ref={inputRef}
            className="visually-hidden"
            type="file"
            accept="*/*"
            onChange={(event) => event.target.files?.[0] && onUpload(event.target.files[0])}
          />
          <span className="big-upload-icon">
            {uploadedFile ? <CheckCircle size={30} weight="fill" /> : <UploadSimple size={30} />}
          </span>
          <strong>{uploadedFile ? uploadedFile.name : "把资料放到这里"}</strong>
          <p>
            {uploadedFile
              ? "文件已在本地读取，可以开始生成学习路径"
              : "支持教材、论文、笔记、网页导出等常见格式"}
          </p>
          <span className="button button-soft">{uploadedFile ? "更换文件" : "选择文件"}</span>
        </button>
        <div className="or-divider"><span>或者从精选知识包开始</span></div>
        <div className="material-pack-list">
          {knowledgePacks.map((pack, index) => (
            <button
              className={selectedPack === pack.id ? "selected" : ""}
              type="button"
              onClick={() => setSelectedPack(pack.id)}
              key={pack.id}
            >
              <span className={`pack-icon pack-${pack.accent}`}>
                {index === 0 ? <Brain size={23} /> : index === 1 ? <ChartBar size={23} /> : <Compass size={23} />}
              </span>
              <div>
                <Tag tone={pack.accent}>{pack.title}</Tag>
                <strong>{pack.subtitle}</strong>
                <small>{pack.meta}</small>
              </div>
              <span className="radio-mark">{selectedPack === pack.id && <Check size={14} weight="bold" />}</span>
            </button>
          ))}
        </div>
      </div>
      <div className="stage-footer">
        <div>
          <ShieldCheck size={18} weight="fill" />
          <span>演示版仅在当前浏览器中处理所选文件，不会上传。</span>
        </div>
        <button className="button button-primary button-large" type="button" onClick={onGenerate} disabled={analyzing}>
          {analyzing ? (
            <>
              <CircleNotch className="spin" size={19} /> 正在分析资料…
            </>
          ) : (
            <>
              生成学习路径 <ArrowRight size={18} />
            </>
          )}
        </button>
      </div>
    </section>
  );
}

function MapStage({ selectedNode, onSelectNode, onStartLesson }) {
  const selectedStep = LEARNING_PATH.find((item) => item.id === selectedNode) || LEARNING_PATH[1];
  return (
    <section className="map-stage">
      <div className="map-stage-header">
        <div>
          <Tag tone="lavender">第二步 · 确认学习路径</Tag>
          <h1>双系统思维，会这样一步一步学</h1>
          <p>这不是一张知识脑图，而是本次学习的实际顺序。每一步都说明学什么、怎么学，以及做到什么才算完成。</p>
        </div>
        <span className="path-total"><ClockCounterClockwise size={17} /> 约 46 分钟 · 6 个步骤</span>
      </div>
      <div className="learning-path-list">
        {LEARNING_PATH.map((item, index) => (
          <button
            type="button"
            key={item.id}
            className={`path-step ${item.status} ${selectedNode === item.id ? "selected" : ""}`}
            onClick={() => onSelectNode(item.id)}
          >
            <span className="path-step-number">{item.status === "completed" ? <Check size={16} weight="bold" /> : index + 1}</span>
            <div className="path-step-main">
              <span>{item.status === "completed" ? "已完成" : item.status === "current" ? "从这里开始" : `第 ${index + 1} 步`}</span>
              <strong>{item.title}</strong>
              <p>{item.goal}</p>
            </div>
            <div className="path-step-method">
              <small>学习方式</small>
              <strong>{item.method}</strong>
            </div>
            <span className="path-step-duration">{item.duration}</span>
            <CaretRight size={17} />
          </button>
        ))}
      </div>
      <article className="path-confirmation">
        <span className="path-confirmation-icon"><Target size={22} weight="duotone" /></span>
        <div>
          <small>完成标准</small>
          <h2>{selectedStep.title}</h2>
          <p>{selectedStep.doneWhen}</p>
        </div>
        <button className="button button-primary" type="button" onClick={onStartLesson}>
          确认路径，从简单讲解开始 <ArrowRight size={17} />
        </button>
      </article>
    </section>
  );
}

function LessonStage({ onCheck, onBack }) {
  const [bookmarked, setBookmarked] = useState(false);
  return (
    <section className="lesson-stage">
      <button className="back-link" type="button" onClick={onBack}>
        <ArrowLeft size={16} /> 返回学习地图
      </button>
      <article className="lesson-paper">
        <div className="lesson-title-row">
          <div>
            <Tag tone="lavender">概念 3 / 8</Tag>
            <h1>什么是双系统思维？</h1>
          </div>
          <button
            className={`icon-button ${bookmarked ? "active" : ""}`}
            type="button"
            onClick={() => setBookmarked((value) => !value)}
            aria-label="收藏知识点"
          >
            <Star size={22} weight={bookmarked ? "fill" : "regular"} />
          </button>
        </div>
        <section className="lesson-plan">
          <div>
            <span><BookOpen size={20} weight="fill" /></span>
            <div>
              <small>本节怎么讲</small>
              <strong>先抓住一句话，再看生活例子，最后比较两套系统</strong>
            </div>
          </div>
          <ol>
            <li><b>1</b><span>一句话建立直觉</span></li>
            <li><b>2</b><span>生活场景验证</span></li>
            <li><b>3</b><span>完整对比与边界</span></li>
          </ol>
          <p>你不必等到页面底部。任何时候觉得已经全部理解，都可以直接进入掌握检查；没通过时，我们会带你回到对应位置。</p>
        </section>
        <p className="lesson-lead">
          你可以把大脑想成一间同时有两位同事工作的办公室：一位反应快，另一位想得深。
        </p>
        <div className="analogy-note always-visible">
          <span><Lightbulb size={21} weight="fill" /></span>
          <div>
            <strong>一直放在这里的生活例子</strong>
            <p>
              你在常去的咖啡店里点单，几乎不用想，这是系统 1；但当店员给你一张复杂的会员方案表，你开始计算哪种更划算，系统 2 就接手了。
            </p>
          </div>
        </div>
        <div className="systems-compare">
          <section>
            <span className="system-number lavender">1</span>
            <div>
              <Tag tone="lavender">快思考</Tag>
              <h2>系统 1</h2>
              <p>自动、快速、几乎不费力。它依赖经验和联想，帮助你在熟悉情境里迅速行动。</p>
              <ul>
                <li><Check size={15} /> 看到笑脸，立刻感知情绪</li>
                <li><Check size={15} /> 走熟悉的路，不必刻意思考</li>
              </ul>
            </div>
          </section>
          <div className="brain-divider" aria-label="双系统协同">
            <Brain size={54} weight="duotone" />
            <strong>快 ↔ 慢</strong>
            <span>两套系统协同工作</span>
          </div>
          <section>
            <span className="system-number peach">2</span>
            <div>
              <Tag tone="peach">慢思考</Tag>
              <h2>系统 2</h2>
              <p>有意识、缓慢、需要精力。它会在问题复杂、重要或陌生时接过控制权。</p>
              <ul>
                <li><Check size={15} /> 比较两份合同的长期成本</li>
                <li><Check size={15} /> 推理一道陌生的逻辑题</li>
              </ul>
            </div>
          </section>
        </div>
        <div className="lesson-insight">
          <Lightbulb size={23} weight="fill" />
          <div>
            <strong>关键不是谁更“正确”</strong>
            <p>两套系统都不可缺少。真正重要的是：知道什么时候可以相信直觉，什么时候应该停下来检查。</p>
          </div>
        </div>
        <div className="source-citation">
          <FilePdf size={18} weight="fill" />
          <div>
            <small>资料来源</small>
            <strong>《思考，快与慢》· 第 20—38 页</strong>
          </div>
          <CaretRight size={16} />
        </div>
        <div className="lesson-actions">
          <button className="button button-primary button-large" type="button" onClick={onCheck}>
            我全部理解了，去检查一下 <ArrowRight size={18} />
          </button>
          <span>检查会验证你是否真的能区分两套系统</span>
        </div>
      </article>
      <div className="ask-strip">
        <span><Sparkle size={18} weight="fill" /></span>
        <input aria-label="向 AI 提问" placeholder="有哪里还没想通？继续问我…" />
        <button type="button" aria-label="语音输入"><Microphone size={19} /></button>
        <button type="button" aria-label="发送"><PaperPlaneTilt size={19} weight="fill" /></button>
      </div>
    </section>
  );
}

function CheckStage({ selectedAnswer, onSelect, onDeep, onBack }) {
  const options = [
    "系统 1 总是容易出错，系统 2 总是正确",
    "系统 1 负责快速直觉，系统 2 负责需要注意力的分析",
    "只有经过专业训练的人才会使用系统 2",
    "系统 1 与系统 2 不会在同一个问题里共同工作",
  ];
  return (
    <section className="check-stage">
      <button className="back-link" type="button" onClick={onBack}>
        <ArrowLeft size={16} /> 返回讲解
      </button>
      <article className="check-card">
        <div className="check-progress">
          <span>理解检查</span>
          <strong>1 / 2</strong>
          <i><b style={{ width: "50%" }} /></i>
        </div>
        <Tag tone="peach">先凭自己的理解回答</Tag>
        <h1>下面哪句话最准确地描述了系统 1 与系统 2？</h1>
        <div className="answer-list">
          {options.map((option, index) => {
            const chosen = selectedAnswer === index;
            const correct = index === 1;
            return (
              <button
                type="button"
                key={option}
                className={`${chosen ? "selected" : ""} ${chosen && correct ? "correct" : ""} ${chosen && !correct ? "wrong" : ""}`}
                onClick={() => onSelect(index)}
              >
                <span>{String.fromCharCode(65 + index)}</span>
                <strong>{option}</strong>
                {chosen && (correct ? <CheckCircle size={22} weight="fill" /> : <X size={22} weight="bold" />)}
              </button>
            );
          })}
        </div>
        {selectedAnswer !== null && (
          <div className={`answer-feedback ${selectedAnswer === 1 ? "success" : "retry"}`}>
            {selectedAnswer === 1 ? <CheckCircle size={23} weight="fill" /> : <Lightbulb size={23} weight="fill" />}
            <div>
              <strong>{selectedAnswer === 1 ? "理解准确" : "再看一眼关键区别"}</strong>
              <p>
                {selectedAnswer === 1
                  ? "两套系统不是正确与错误的对立，而是在速度、注意力与适用情境上不同。"
                  : "系统 1 也能在熟悉情境中非常有效；系统 2 也可能因为信息不足而判断失误。"}
              </p>
            </div>
          </div>
        )}
        <div className="check-actions">
          <button className="button button-ghost" type="button" onClick={onBack}>
            回看讲解
          </button>
          <button className="button button-primary" type="button" onClick={onDeep} disabled={selectedAnswer !== 1}>
            进入深度学习 <ArrowRight size={17} />
          </button>
        </div>
      </article>
    </section>
  );
}

function DeepStage({ mode, onMode, mastery, onMastery, onToast, onBackMap }) {
  const [input, setInput] = useState("");
  const [submitted, setSubmitted] = useState("");
  const [thinking, setThinking] = useState(false);
  const [feedback, setFeedback] = useState(null);
  const [listening, setListening] = useState(false);

  const submit = () => {
    const trimmed = input.trim();
    if (!trimmed) return;
    setSubmitted(trimmed);
    setInput("");
    setFeedback(null);
    setThinking(true);
    window.setTimeout(() => {
      setThinking(false);
      setFeedback(feedbackByMode[mode]);
      onMastery(Math.max(mastery, 68));
    }, 900);
  };

  const switchMode = (nextMode) => {
    onMode(nextMode);
    setFeedback(null);
    setSubmitted("");
  };

  const toggleMic = () => {
    setListening((value) => !value);
    onToast(listening ? "已停止语音输入演示" : "麦克风为交互占位，正式版将接入语音转写");
  };

  return (
    <section className="deep-stage">
      <div className="deep-main">
        <div className="deep-heading">
          <div>
            <Tag tone="lavender">深度学习 · 费曼 / 苏格拉底</Tag>
            <h1>{mode === "feynman" ? "费曼学习法：你讲，我来找遗漏" : "苏格拉底学习法：我问，你来推理"}</h1>
            <p>随时切换两种方式；系统会保留同一个知识点与学习进度。</p>
          </div>
          <button className="map-return" type="button" onClick={onBackMap}>
            <MapTrifold size={17} /> 回看学习路径
          </button>
        </div>
        <div className="mode-switch" role="tablist" aria-label="学习模式">
          <button
            type="button"
            className={mode === "feynman" ? "active" : ""}
            onClick={() => switchMode("feynman")}
          >
            <span><GraduationCap size={22} weight="fill" /></span>
            <div>
              <strong>费曼学习法</strong>
              <small>你讲，我复述并找出遗漏</small>
            </div>
            <i>{mode === "feynman" && <Check size={13} weight="bold" />}</i>
          </button>
          <button
            type="button"
            className={mode === "socratic" ? "active" : ""}
            onClick={() => switchMode("socratic")}
          >
            <span><Question size={22} weight="bold" /></span>
            <div>
              <strong>苏格拉底学习法</strong>
              <small>我连续追问，陪你检查假设</small>
            </div>
            <i>{mode === "socratic" && <Check size={13} weight="bold" />}</i>
          </button>
        </div>
        <div className="conversation">
          <article className="ai-message">
            <span className="ai-avatar"><Sparkle size={18} weight="fill" /></span>
            <div>
              <small>AI 学习伙伴 · 当前为{mode === "feynman" ? "费曼学习法" : "苏格拉底学习法"}</small>
              <p>
                {mode === "feynman"
                  ? "请把我当成一个完全没学过心理学的人。你能用一个生活中的例子，讲清楚系统 1 和系统 2 的区别吗？"
                  : "你刚才说系统 2 更适合复杂问题。我们先从一个问题开始：你如何判断一个问题是否“复杂”？"}
              </p>
            </div>
          </article>
          {submitted && (
            <article className="user-message">
              <div>
                <small>你的讲解</small>
                <p>{submitted}</p>
              </div>
              <span className="avatar">LX</span>
            </article>
          )}
          {thinking && (
            <article className="ai-message thinking-message">
              <span className="ai-avatar"><Sparkle size={18} weight="fill" /></span>
              <div>
                <small>正在整理你的表达</small>
                <p><i /><i /><i /></p>
              </div>
            </article>
          )}
          {feedback && (
            <article className="teacher-feedback">
              <div>
                <span className="feedback-icon recap"><PencilSimple size={19} weight="fill" /></span>
                <div>
                  <strong>我先复述一下你的意思</strong>
                  <p>{feedback.recap}</p>
                </div>
              </div>
              <div>
                <span className="feedback-icon probe"><Question size={19} weight="bold" /></span>
                <div>
                  <strong>我想再追问一处</strong>
                  <p>{feedback.probe}</p>
                </div>
              </div>
              <div className="feedback-meta">
                <Tag tone="green">掌握度 +16%</Tag>
                <span>已写入认知校准档案</span>
              </div>
            </article>
          )}
        </div>
        <div className={`deep-composer ${listening ? "listening" : ""}`}>
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder={
              mode === "feynman"
                ? "像教一个完全不了解的人那样讲讲看…"
                : "写下你的判断，AI 会继续追问…"
            }
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                submit();
              }
            }}
          />
          <div>
            <button
              className={`mic-button ${listening ? "active" : ""}`}
              type="button"
              onClick={toggleMic}
              aria-label="语音输入"
            >
              <Microphone size={20} weight={listening ? "fill" : "regular"} />
              <span>{listening ? "正在聆听" : "语音"}</span>
            </button>
            <span>Enter 发送 · Shift + Enter 换行</span>
            <button className="button button-primary" type="button" onClick={submit} disabled={!input.trim()}>
              发送 <PaperPlaneTilt size={17} weight="fill" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Workspace({
  stage,
  setStage,
  uploadedFile,
  onUpload,
  mastery,
  setMastery,
  onNavigate,
  onToast,
}) {
  const [selectedNode, setSelectedNode] = useState("system1");
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [mode, setMode] = useState("feynman");
  const [analyzing, setAnalyzing] = useState(false);
  const [sourceOpen, setSourceOpen] = useState(false);

  const generateMap = () => {
    setAnalyzing(true);
    window.setTimeout(() => {
      setAnalyzing(false);
      setStage("map");
      onToast("学习路径已生成：共规划 6 个可执行步骤");
    }, 900);
  };

  const chooseAnswer = (index) => {
    setSelectedAnswer(index);
    if (index === 1) setMastery(Math.max(mastery, 52));
  };

  return (
    <main className="workspace-page">
      <header className="workspace-topbar">
        <div className="workspace-breadcrumb">
          <button type="button" onClick={() => onNavigate("library")}><ArrowLeft size={17} /> 返回领域书架</button>
          <span />
          <div><small>心理学知识包</small><strong>双系统思维</strong></div>
        </div>
        <div className="workspace-topbar-actions">
          {stage !== "materials" && (
            <button className={sourceOpen ? "active" : ""} type="button" onClick={() => setSourceOpen((value) => !value)}>
              <FileText size={17} /> {sourceOpen ? "隐藏资料侧栏" : "查看资料摘录"}
            </button>
          )}
          <button type="button" onClick={() => onNavigate("desk")}><House size={17} /> 回到今日桌面</button>
        </div>
      </header>
      <StageNav activeStage={stage} onChange={setStage} />
      <div className={`workspace-layout stage-${stage} ${sourceOpen && stage !== "materials" ? "source-visible" : "source-hidden"}`}>
        {stage !== "materials" && sourceOpen && (
          <SourceDrawer uploadedFile={uploadedFile} onUpload={onUpload} compact={stage === "deep"} />
        )}
        <div className="workspace-content">
          {stage === "materials" && (
            <MaterialsStage
              uploadedFile={uploadedFile}
              onUpload={onUpload}
              onGenerate={generateMap}
              analyzing={analyzing}
            />
          )}
          {stage === "map" && (
            <MapStage
              selectedNode={selectedNode}
              onSelectNode={setSelectedNode}
              onStartLesson={() => setStage("lesson")}
            />
          )}
          {stage === "lesson" && (
            <LessonStage onCheck={() => setStage("check")} onBack={() => setStage("map")} />
          )}
          {stage === "check" && (
            <CheckStage
              selectedAnswer={selectedAnswer}
              onSelect={chooseAnswer}
              onDeep={() => setStage("deep")}
              onBack={() => setStage("lesson")}
            />
          )}
          {stage === "deep" && (
            <DeepStage
              mode={mode}
              onMode={setMode}
              mastery={mastery}
              onMastery={setMastery}
              onToast={onToast}
              onBackMap={() => setStage("map")}
            />
          )}
        </div>
        {stage !== "materials" && (
          <ProgressAside mastery={mastery} stage={stage} onNavigate={onNavigate} onViewPath={() => setStage("map")} />
        )}
      </div>
    </main>
  );
}

function LearningCenter({ onOpenSettings, onToast }) {
  const [tab, setTab] = useState("overview");
  const [homeReminder, setHomeReminder] = useState(true);
  const [voice, setVoice] = useState(false);
  const [exampleFirst, setExampleFirst] = useState(true);
  const [personality, setPersonality] = useState("balanced");
  const [warmth, setWarmth] = useState(72);
  const [challenge, setChallenge] = useState(64);
  const [depth, setDepth] = useState(78);
  const [initiative, setInitiative] = useState(58);
  return (
    <main className="page center-page">
      <section className="center-hero">
        <div className="center-profile">
          <span className="avatar avatar-large">LX</span>
          <div>
            <Tag tone="lavender">个人学习中心</Tag>
            <h1>Lia Xuan</h1>
            <p>在这里回看你的学习历史、认知校准记录和逐渐形成的学习画像。</p>
          </div>
        </div>
        <button className="button button-ghost" type="button" onClick={onOpenSettings}>
          <Gear size={18} /> 个人设置
        </button>
      </section>
      <nav className="center-tabs" aria-label="学习中心分类">
        {[
          ["overview", "学习概览"],
          ["history", "学习历史"],
          ["calibration", "认知校准档案"],
          ["profile", "学习画像"],
          ["preferences", "学习偏好"],
        ].map(([id, label]) => (
          <button className={tab === id ? "active" : ""} type="button" key={id} onClick={() => setTab(id)}>
            {label}
          </button>
        ))}
      </nav>

      {tab === "overview" && (
        <>
          <section className="stat-grid">
            <article>
              <span className="stat-icon pink"><BookOpen size={22} /></span>
              <div><strong>12</strong><span>已学习概念</span></div>
              <Tag tone="green">本周 +4</Tag>
            </article>
            <article>
              <span className="stat-icon lavender"><ClockCounterClockwise size={22} /></span>
              <div><strong>4.6h</strong><span>深度学习时间</span></div>
              <Tag tone="lavender">连续 12 天</Tag>
            </article>
            <article>
              <span className="stat-icon peach"><TrendUp size={22} /></span>
              <div><strong>74%</strong><span>平均掌握度</span></div>
              <Tag tone="green">提升 9%</Tag>
            </article>
            <article>
              <span className="stat-icon green"><SealCheck size={22} /></span>
              <div><strong>8</strong><span>已完成校准</span></div>
              <Tag tone="peach">3 个待验证</Tag>
            </article>
          </section>
          <section className="learner-observation">
            <div className="observation-intro">
              <span className="observation-avatar"><Sparkle size={24} weight="fill" /></span>
              <div>
                <span className="eyebrow">AI 学习伙伴观察</span>
                <h2>你理解得快，也愿意把概念讲成自己的话</h2>
                <p>根据最近 12 个概念、3 次互动复述与认知校准记录生成。随着学习继续，这段描述也会更新。</p>
              </div>
              <Tag tone="lavender">场景驱动型</Tag>
            </div>
            <div className="observation-columns">
              <article className="observation-praise">
                <span><SealCheck size={20} weight="fill" /></span>
                <div>
                  <small>值得表扬</small>
                  <strong>你很会用具体例子抓住抽象概念</strong>
                  <p>在心理学和产品分析中，你能迅速找到生活场景，还会主动用自己的语言复述。这让你的理解不容易停留在“看懂了”。</p>
                </div>
              </article>
              <article className="observation-improve">
                <span><TrendUp size={20} weight="bold" /></span>
                <div>
                  <small>优先改进</small>
                  <strong>把推理再往后多走两步</strong>
                  <p>你的第一层判断通常很准，但遇到复杂问题时，容易略过中间条件。接下来要多练“为什么成立、什么时候不成立”。</p>
                </div>
              </article>
              <article className="observation-next">
                <span><Target size={20} weight="bold" /></span>
                <div>
                  <small>接下来怎么练</small>
                  <strong>每次复述都补一个反例</strong>
                  <p>先举自己的例子，再解释成立原因，最后补一个边界反例。建议本周完成 3 次 10 分钟的苏格拉底追问。</p>
                </div>
                <button type="button" onClick={() => setTab("profile")}>查看完整建议 <ArrowRight size={15} /></button>
              </article>
            </div>
          </section>
          <section className="center-grid">
            <article className="history-panel">
              <div className="panel-heading">
                <div><span className="eyebrow">最近学习</span><h2>继续你的学习轨迹</h2></div>
                <button className="text-button" type="button" onClick={() => setTab("history")}>查看全部</button>
              </div>
              <HistoryTable items={historyItems} />
            </article>
            <article className="profile-panel">
              <span className="eyebrow">学习画像摘要</span>
              <h2>偏好“例子 → 概念”</h2>
              <p>你在先看到具体场景时，能更快形成稳定理解。</p>
              <div className="profile-score">
                <label><span>例子联想</span><i><b style={{ width: "86%" }} /></i><strong>86</strong></label>
                <label><span>概念复述</span><i><b style={{ width: "72%" }} /></i><strong>72</strong></label>
                <label><span>连续推理</span><i><b style={{ width: "58%" }} /></i><strong>58</strong></label>
                <label><span>迁移应用</span><i><b style={{ width: "64%" }} /></i><strong>64</strong></label>
              </div>
              <button className="button button-soft button-full" type="button" onClick={() => setTab("profile")}>
                查看完整画像
              </button>
            </article>
          </section>
          <section className="weakness-panel">
            <div className="panel-heading">
              <div>
                <span className="eyebrow">当前薄弱环节</span>
                <h2>最值得优先澄清的 3 个地方</h2>
                <p>这是认知校准档案里仍未稳定掌握的部分，不等于“做错了”。</p>
              </div>
              <button className="button button-soft" type="button" onClick={() => setTab("calibration")}>查看校准档案</button>
            </div>
            <div className="weakness-grid">
              <article><span>01</span><div><strong>复杂概念的连续推理</strong><p>能理解每一步，但跨三步以上时容易漏掉中间条件。</p></div><Tag tone="peach">优先练习</Tag></article>
              <article><span>02</span><div><strong>反例与边界条件</strong><p>复述主结论很清楚，还需要主动补充“不适用的情境”。</p></div><Tag tone="lavender">待验证</Tag></article>
              <article><span>03</span><div><strong>跨场景迁移</strong><p>熟悉案例中表现稳定，换到陌生领域时需要更多提示。</p></div><Tag tone="pink">可提升</Tag></article>
            </div>
          </section>
        </>
      )}

      {tab === "history" && (
        <section className="full-panel">
          <div className="panel-heading">
            <div><span className="eyebrow">学习历史</span><h2>每一次理解都留有轨迹</h2></div>
            <button className="button button-soft" type="button"><FileText size={17} /> 导出记录</button>
          </div>
          <HistoryTable items={historyItems} detailed />
        </section>
      )}

      {tab === "calibration" && (
        <section className="full-panel">
          <div className="panel-heading">
            <div>
              <span className="eyebrow">认知校准档案</span>
              <h2>记录仍需澄清、验证与迁移的地方</h2>
              <p>它不是“错题本”，而是一份不断修正理解边界的专业记录。</p>
            </div>
            <Tag tone="peach">3 项待处理</Tag>
          </div>
          <div className="calibration-list">
            {calibrationItems.map((item) => (
              <article key={item.title}>
                <span className={`calibration-state ${item.type === "已校准" ? "done" : ""}`}>
                  {item.type === "已校准" ? <Check size={17} weight="bold" /> : <Question size={17} weight="bold" />}
                </span>
                <div>
                  <div><strong>{item.title}</strong><Tag tone={item.type === "已校准" ? "green" : "peach"}>{item.type}</Tag></div>
                  <p>{item.detail}</p>
                  <small>{item.date}</small>
                </div>
                <button className="icon-button" type="button"><CaretRight size={18} /></button>
              </article>
            ))}
          </div>
        </section>
      )}

      {tab === "profile" && (
        <section className="profile-deep-grid">
          <article className="full-panel profile-story">
            <Tag tone="lavender">你的学习方式</Tag>
            <h2>你是一位“场景驱动型”学习者</h2>
            <p>你会先寻找概念在真实世界里的落点，再从例子中提炼结构。比起一次接收大量定义，你更适合小步讲解、短反馈和频繁复述。</p>
            <div className="profile-facts">
              <span><strong>理解入口</strong> 真实案例</span>
              <span><strong>最佳节奏</strong> 10–20 分钟</span>
              <span><strong>适合模式</strong> 费曼优先</span>
              <span><strong>反馈偏好</strong> 先肯定再追问</span>
            </div>
            <div className="profile-highlight">
              <Lightbulb size={24} weight="fill" />
              <div>
                <strong>给你的建议</strong>
                <p>每学完一个概念，先举一个自己的例子，再向 AI 解释“为什么这个例子成立”；最后补一个反例，训练边界判断。</p>
              </div>
            </div>
          </article>
          <article className="full-panel">
            <span className="eyebrow">能力侧写</span>
            <h2>理解速度快，迁移能力正在形成</h2>
            <p className="ability-summary">你擅长把抽象概念映射到熟悉场景；下一阶段的关键是延长推理链，并主动寻找反例。</p>
            <div className="profile-score large">
              <label><span>例子联想</span><i><b style={{ width: "86%" }} /></i><strong>86</strong></label>
              <label><span>概念复述</span><i><b style={{ width: "72%" }} /></i><strong>72</strong></label>
              <label><span>连续推理</span><i><b style={{ width: "58%" }} /></i><strong>58</strong></label>
              <label><span>迁移应用</span><i><b style={{ width: "64%" }} /></i><strong>64</strong></label>
            </div>
            <div className="next-practice">
              <Target size={21} />
              <div><strong>下一次练习建议</strong><span>选择“苏格拉底模式 · 严格反馈”，重点练习连续追问。</span></div>
            </div>
          </article>
        </section>
      )}

      {tab === "preferences" && (
        <section className="preferences-center">
          <div className="preferences-heading">
            <div>
              <Tag tone="lavender">学习偏好与个性化</Tag>
              <h2>把 AI 学习搭档调成适合你的样子</h2>
              <p>这些设置会影响讲解顺序、反馈语气、追问力度和主动提示的频率。</p>
            </div>
            <button className="button button-primary" type="button" onClick={() => onToast("学习偏好已保存")}>
              保存偏好
            </button>
          </div>

          <div className="preferences-layout">
            <article className="full-panel preference-basics">
              <div className="panel-heading">
                <div><span className="eyebrow">学习方式</span><h2>什么时候提醒，怎么开始讲</h2></div>
              </div>
              <SettingToggle
                icon={Bell}
                title="首页学习提醒"
                description="只在你打开今日桌面时显示温和提醒，不发送系统推送"
                checked={homeReminder}
                onChange={setHomeReminder}
              />
              <SettingToggle
                icon={Microphone}
                title="保留语音输入入口"
                description="优先使用文字；需要时可以切换语音复述"
                checked={voice}
                onChange={setVoice}
              />
              <SettingToggle
                icon={BookOpen}
                title="先例子，后定义"
                description="新概念优先从生活场景开始，再总结正式定义"
                checked={exampleFirst}
                onChange={setExampleFirst}
              />
              <div className="reminder-boundary">
                <ShieldCheck size={18} weight="fill" />
                <span><strong>提醒边界</strong> 不申请系统推送权限，也不会向邮箱发送催学消息。</span>
              </div>
            </article>

            <article className="full-panel personalization-panel">
              <div className="panel-heading">
                <div><span className="eyebrow">个性与智能性</span><h2>先选一种基础风格</h2><p>类似 ChatGPT 的个性化方式：先选整体风格，再微调具体特质。</p></div>
                <Tag tone="pink">随时可改</Tag>
              </div>
              <div className="personality-grid expanded">
                {[
                  ["balanced", "均衡", "清楚、自然，保留思考空间", Sparkle],
                  ["warm", "温暖", "更耐心地复述与鼓励", SealCheck],
                  ["candid", "直率", "直接指出漏洞，减少客套", Target],
                  ["creative", "灵感型", "多用类比与跨领域连接", Lightbulb],
                ].map(([id, title, copy, Icon]) => (
                  <button className={personality === id ? "selected" : ""} type="button" key={id} onClick={() => setPersonality(id)}>
                    <span><Icon size={21} weight="duotone" /></span>
                    <strong>{title}</strong>
                    <small>{copy}</small>
                    {personality === id && <CheckCircle size={18} weight="fill" />}
                  </button>
                ))}
              </div>
              <div className="trait-sliders">
                {[
                  ["温暖程度", warmth, setWarmth, "从冷静克制到温和陪伴"],
                  ["挑战强度", challenge, setChallenge, "从多给提示到持续追问"],
                  ["解释深度", depth, setDepth, "从快速结论到完整推导"],
                  ["主动程度", initiative, setInitiative, "从等你提问到主动建议下一步"],
                ].map(([label, value, setter, copy]) => (
                  <label key={label}>
                    <span><strong>{label}</strong><small>{copy}</small></span>
                    <input type="range" min="0" max="100" value={value} onChange={(event) => setter(Number(event.target.value))} />
                    <b>{value}</b>
                  </label>
                ))}
              </div>
            </article>
          </div>

          <article className="full-panel custom-context-panel">
            <div className="panel-heading">
              <div><span className="eyebrow">让 AI 更了解你</span><h2>补充少量背景，就能得到更贴合的讲解</h2></div>
            </div>
            <div className="custom-context-grid">
              <label>AI 应该怎么称呼你？<input defaultValue="Lia" /></label>
              <label>你现在主要在做什么？<input defaultValue="AI 产品经理，正在学习智能体、Workflow 与连接器" /></label>
              <label>你希望 AI 具备哪些特质？<textarea defaultValue="先复述我的意思，再指出遗漏；讲解要简单但不要过度简化。" /></label>
              <label>还有什么需要了解？<textarea defaultValue="我喜欢从真实案例开始，也希望被追问概念的边界和反例。" /></label>
            </div>
          </article>
        </section>
      )}
    </main>
  );
}

function HistoryTable({ items, detailed = false }) {
  return (
    <div className="history-table">
      {items.map((item) => (
        <article key={item.topic}>
          <span className="history-icon"><BookOpen size={19} /></span>
          <div className="history-topic">
            <strong>{item.topic}</strong>
            <span>{item.pack} · {item.date}</span>
          </div>
          {detailed && <span className="history-mode">费曼模式 2 次</span>}
          <div className="history-mastery">
            <span>{item.mastery}%</span>
            <i><b style={{ width: `${item.mastery}%` }} /></i>
          </div>
          <Tag tone={item.status === "已完成" ? "green" : item.status === "学习中" ? "pink" : "lavender"}>
            {item.status}
          </Tag>
          <button className="icon-button" type="button"><CaretRight size={17} /></button>
        </article>
      ))}
    </div>
  );
}

function SettingsPage({
  session,
  apiKey,
  onSaveKey,
  onLogout,
  onBack,
  onToast,
  language,
  onLanguage,
}) {
  const [tab, setTab] = useState("account");
  const [draftKey, setDraftKey] = useState(apiKey);

  const saveKey = () => {
    onSaveKey(draftKey);
    onToast(draftKey ? "API Key 已保存在当前浏览器" : "API Key 已清除");
  };

  return (
    <main className="page settings-page">
      <button className="back-link" type="button" onClick={onBack}><ArrowLeft size={16} /> 返回数字书桌</button>
      <div className="settings-heading">
        <div><Tag tone="lavender">个人设置</Tag><h1>让书桌更适合你</h1></div>
      </div>
      <div className="settings-layout">
        <nav className="settings-nav" aria-label="设置分类">
          <button className={tab === "account" ? "active" : ""} type="button" onClick={() => setTab("account")}><UserCircle size={19} /> 账号与资料</button>
          <button className={tab === "ai" ? "active" : ""} type="button" onClick={() => setTab("ai")}><Key size={19} /> AI 与 API Key</button>
          <button className={tab === "privacy" ? "active" : ""} type="button" onClick={() => setTab("privacy")}><ShieldCheck size={19} /> 隐私与数据</button>
          <button className="logout" type="button" onClick={onLogout}><SignOut size={19} /> 退出登录</button>
        </nav>
        <section className="settings-panel">
          {tab === "account" && (
            <>
              <div className="panel-heading"><div><h2>账号与资料</h2><p>这些信息只用于你的学习空间。</p></div></div>
              <div className="profile-edit">
                <span className="avatar avatar-large">LX</span>
                <button className="button button-soft" type="button">更换头像</button>
              </div>
              <div className="settings-form-grid">
                <label>显示名称<input defaultValue={session?.name || "Lia Xuan"} /></label>
                <label>邮箱<input defaultValue={session?.email || "demo@example.com"} /></label>
                <label>界面语言<select value={language} onChange={(event) => onLanguage(event.target.value)}>{LANGUAGE_OPTIONS.map((item) => <option value={item.id} key={item.id}>{item.label}</option>)}</select></label>
                <label>所在时区<select defaultValue="shanghai"><option value="shanghai">Asia / Shanghai</option></select></label>
              </div>
              <div className="settings-save-row"><button className="button button-primary" type="button" onClick={() => onToast("个人资料已保存")}>保存修改</button></div>
            </>
          )}
          {tab === "ai" && (
            <>
              <div className="panel-heading">
                <div><h2>AI 与 API Key</h2><p>使用你自己的 Key 连接真实 AI；演示模式不会发送外部请求。</p></div>
                <Tag tone={apiKey ? "green" : "peach"}>{apiKey ? "已配置" : "演示模式"}</Tag>
              </div>
              <div className="provider-card selected">
                <span><Sparkle size={20} weight="fill" /></span>
                <div><strong>OpenAI-compatible API</strong><p>支持标准 Chat Completions 接口</p></div>
                <CheckCircle size={20} weight="fill" />
              </div>
              <label className="key-field settings-key">
                API Key
                <div>
                  <LockKey size={19} />
                  <input type="password" value={draftKey} onChange={(event) => setDraftKey(event.target.value)} placeholder="sk-••••••••••••••••" />
                  {draftKey && <button type="button" onClick={() => setDraftKey("")}>清除</button>}
                </div>
              </label>
              <label className="full-label">API Base URL<input defaultValue="https://api.openai.com/v1" /></label>
              <label className="full-label">默认模型<select defaultValue="auto"><option value="auto">自动选择推荐模型</option><option value="custom">自定义模型</option></select></label>
              <div className="privacy-note"><ShieldCheck size={20} weight="fill" /><span>Key 仅保存在你的浏览器中。正式上线前还需要做安全代理与费用保护。</span></div>
              <div className="settings-save-row"><button className="button button-primary" type="button" onClick={saveKey}>保存并测试连接</button></div>
            </>
          )}
          {tab === "privacy" && (
            <>
              <div className="panel-heading"><div><h2>隐私与数据</h2><p>管理保存在浏览器中的学习记录。</p></div></div>
              <div className="privacy-data-card">
                <span><ShieldCheck size={24} weight="fill" /></span>
                <div><strong>你的资料由你掌控</strong><p>这个前端 Demo 的账号、API Key 和学习状态仅存于当前浏览器。</p></div>
              </div>
              <div className="data-row"><div><strong>学习历史</strong><span>3 个主题，12 个概念</span></div><button className="button button-soft" type="button">导出</button></div>
              <div className="data-row"><div><strong>清除本地学习数据</strong><span>这不会删除你的演示账号</span></div><button className="button button-danger" type="button" onClick={() => onToast("演示数据已恢复为初始状态")}>清除</button></div>
            </>
          )}
        </section>
      </div>
    </main>
  );
}

function SettingToggle({ icon: Icon, title, description, checked, onChange }) {
  return (
    <div className="setting-toggle">
      <span><Icon size={21} /></span>
      <div><strong>{title}</strong><small>{description}</small></div>
      <button className={`toggle ${checked ? "on" : ""}`} type="button" onClick={() => onChange(!checked)} aria-pressed={checked}><i /></button>
    </div>
  );
}

function MobileNav({ page, onNavigate }) {
  return (
    <nav className="mobile-nav" aria-label="手机端导航">
      <button className={page === "desk" ? "active" : ""} type="button" onClick={() => onNavigate("desk")}><House size={20} /><span>今日</span></button>
      <button className={page === "library" ? "active" : ""} type="button" onClick={() => onNavigate("library")}><Books size={20} /><span>书架</span></button>
      <button className={page === "workspace" ? "active" : ""} type="button" onClick={() => onNavigate("workspace")}><MapTrifold size={20} /><span>学习</span></button>
      <button className={page === "center" ? "active" : ""} type="button" onClick={() => onNavigate("center")}><ChartBar size={20} /><span>中心</span></button>
    </nav>
  );
}

export function App() {
  const [session, setSession] = useState(() => readStorage("lnt_session", null));
  const [apiKey, setApiKey] = useState(() => readStorage("lnt_api_key", ""));
  const [onboarded, setOnboarded] = useState(() => readStorage("lnt_onboarded", false));
  const [page, setPage] = useState(() => (readStorage("lnt_session", null) ? "desk" : "home"));
  const [authOpen, setAuthOpen] = useState(false);
  const [tourOpen, setTourOpen] = useState(false);
  const [connectOpen, setConnectOpen] = useState(false);
  const [selectedPack, setSelectedPack] = useState(null);
  const [stage, setStage] = useState("materials");
  const [uploadedFile, setUploadedFile] = useState(null);
  const [mastery, setMastery] = useState(36);
  const [toast, setToast] = useState("");
  const [language, setLanguage] = useState(() => readStorage("lnt_language", "zh"));

  const apiConnected = Boolean(apiKey);

  const changeLanguage = (nextLanguage) => {
    const option = LANGUAGE_OPTIONS.find((item) => item.id === nextLanguage) || LANGUAGE_OPTIONS[0];
    setLanguage(option.id);
    writeStorage("lnt_language", option.id);
    document.documentElement.lang = option.locale;
  };

  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(""), 3000);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const option = LANGUAGE_OPTIONS.find((item) => item.id === language) || LANGUAGE_OPTIONS[0];
    document.documentElement.lang = option.locale;
  }, [language]);

  const navigate = (nextPage) => {
    if (!session && nextPage !== "home") {
      setAuthOpen(true);
      return;
    }
    setPage(nextPage);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const login = (user) => {
    setSession(user);
    writeStorage("lnt_session", user);
    setAuthOpen(false);
    setPage("desk");
    if (!onboarded) setTourOpen(true);
  };

  const demoLogin = () => {
    const user = { name: "Lia Xuan", email: "demo@learnnew.app" };
    setSession(user);
    writeStorage("lnt_session", user);
    setAuthOpen(false);
    setPage("desk");
    setTourOpen(true);
  };

  const finishTour = () => {
    setOnboarded(true);
    writeStorage("lnt_onboarded", true);
    setTourOpen(false);
    setToast("引导完成，今天从一个小概念开始吧");
  };

  const startLearning = () => {
    if (!session) {
      setAuthOpen(true);
      return;
    }
    setPage("library");
  };

  const enterPack = (pack) => {
    setSelectedPack(pack);
    if (!apiConnected) {
      setConnectOpen(true);
      return;
    }
    setStage("materials");
    setPage("workspace");
  };

  const enterUploadedFile = (file) => {
    setUploadedFile(file);
    setSelectedPack({ id: "upload", title: file.name });
    setToast(`${file.name} 已放到书桌上`);
    if (!apiConnected) {
      setConnectOpen(true);
      return;
    }
    setStage("materials");
    setPage("workspace");
  };

  const finishConnection = (key) => {
    setApiKey(key);
    writeStorage("lnt_api_key", key);
    setConnectOpen(false);
    setStage("materials");
    setPage("workspace");
    setToast("AI 已连接，正在准备学习地图");
  };

  const continueDemo = () => {
    setConnectOpen(false);
    setStage("materials");
    setPage("workspace");
    setToast("已进入演示模式，不会发起真实 AI 请求");
  };

  const openExistingLearning = () => {
    setStage("lesson");
    setPage("workspace");
  };

  const logout = () => {
    setSession(null);
    writeStorage("lnt_session", null);
    setPage("home");
    setToast("已退出登录");
  };

  const saveApiKey = (value) => {
    setApiKey(value);
    writeStorage("lnt_api_key", value);
  };

  return (
    <div className="app">
      <AppHeader
        session={session}
        apiConnected={apiConnected}
        onLogo={() => navigate(session ? "desk" : "home")}
        onLogin={() => setAuthOpen(true)}
        onNavigate={navigate}
        onLogout={logout}
        language={language}
        onLanguage={changeLanguage}
      />

      {page === "home" && <Landing onLogin={() => setAuthOpen(true)} onDemo={demoLogin} language={language} />}
      {session && page !== "home" && (
        <div className={`signed-layout signed-page-${page}`}>
          <AppSidebar page={page} onNavigate={navigate} />
          <div className="signed-main">
            {page === "desk" && (
              <Desk
                session={session}
                onStart={startLearning}
                onOpenWorkspace={openExistingLearning}
                onNavigate={navigate}
              />
            )}
            {page === "library" && <Library onSelectPack={enterPack} onUpload={enterUploadedFile} />}
            {page === "workspace" && (
              <Workspace
                stage={stage}
                setStage={setStage}
                uploadedFile={uploadedFile}
                onUpload={(file) => {
                  setUploadedFile(file);
                  setToast(`${file.name} 已加入书桌`);
                }}
                mastery={mastery}
                setMastery={setMastery}
                onNavigate={navigate}
                onToast={setToast}
              />
            )}
            {page === "center" && <LearningCenter onOpenSettings={() => navigate("settings")} onToast={setToast} />}
            {page === "settings" && (
              <SettingsPage
                session={session}
                apiKey={apiKey}
                onSaveKey={saveApiKey}
                onLogout={logout}
                onBack={() => navigate("desk")}
                onToast={setToast}
                language={language}
                onLanguage={changeLanguage}
              />
            )}
          </div>
        </div>
      )}

      {session && page !== "home" && <MobileNav page={page} onNavigate={navigate} />}
      {authOpen && (
        <AuthModal
          onClose={() => setAuthOpen(false)}
          onSuccess={login}
          onDemo={demoLogin}
          language={language}
        />
      )}
      {tourOpen && <OnboardingTour onFinish={finishTour} />}
      {connectOpen && (
        <AIConnectionModal
          initialKey={apiKey}
          selectedPack={selectedPack}
          onClose={() => setConnectOpen(false)}
          onConnect={finishConnection}
          onDemo={continueDemo}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle size={19} weight="fill" />
          {toast}
        </div>
      )}
    </div>
  );
}
