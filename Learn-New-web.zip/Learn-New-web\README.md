# Learn New web

Interactive React + Vite prototype for Learn New.

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

Static assets are generated in `dist/client`.

## Current scope

This package contains the public website and interactive product experience. Authentication, cloud records, document parsing, secure AI proxying, and voice input are still prototype integrations and must be implemented before production use.

Never put API keys or private learning materials in front-end source.
